# AI-Powered Smart Retail & Customer Intelligence Platform

## Complete AI/ML Project Documentation

> **Scope:** AI/ML implementation only\
> **Project type:** Reconstructed/re-implemented technical project
> documentation\
> **Platform:** FastAPI-based Smart Retail AI system\
> **Year:** 2026

------------------------------------------------------------------------

## 1. Project Overview

The **AI-Powered Smart Retail & Customer Intelligence Platform** is a
modular AI/ML system designed to demonstrate the integration of computer
vision, natural-language processing, conversational assistance, and API
engineering within a retail-oriented application.

The project contains four primary AI capabilities:

1.  Product image classification
2.  Face verification
3.  Customer sentiment analysis
4.  Retail chatbot

These components are exposed through a common **FastAPI** service layer.
The system also includes validation, health/readiness checks, request
statistics, automated testing, OpenAPI documentation, production
configuration, and Docker-oriented deployment configuration.

This is a **reconstructed/re-implemented project**. Generated datasets,
metrics, screenshots, and evaluation artifacts are therefore
project-development evidence and should not be presented as original
historical internship telemetry.

## 2. Problem Statement

A modern retail application may require product recognition, customer
verification, customer-feedback analysis, and conversational support.
Implementing these functions as disconnected scripts makes integration,
testing, validation, deployment, and maintenance difficult.

The project addresses the engineering problem of integrating multiple
AI/ML capabilities into one modular, testable, API-driven retail
intelligence platform.

## 3. Objectives

-   Develop product image classification.
-   Develop lightweight face verification.
-   Develop three-class retail sentiment analysis.
-   Develop a deterministic retail chatbot.
-   Integrate the modules through FastAPI.
-   Implement input validation and error handling.
-   Implement health/readiness checks.
-   Add request statistics and observability.
-   Provide Swagger/OpenAPI documentation.
-   Perform automated testing.
-   Perform controlled and challenge evaluation.
-   Prepare Docker deployment configuration.
-   Produce reproducible technical evidence.

## 4. Technology Stack

  Technology             Purpose
  ---------------------- -------------------------------------
  Python                 Main implementation language
  FastAPI                API framework and gateway
  Pydantic               Request/response validation
  scikit-learn           Machine-learning algorithms
  scikit-image           HOG feature extraction
  OpenCV                 Image processing and face detection
  NumPy                  Numerical operations
  Pillow                 Image processing
  Joblib                 Model persistence
  Pytest                 Automated testing
  Uvicorn                ASGI server
  OpenAPI / Swagger UI   API documentation
  Docker                 Deployment configuration
  Docker Compose         Container configuration

## 5. System Architecture

``` text
                         CLIENT
                           |
                           v
                    +--------------+
                    |   FastAPI    |
                    |   Gateway    |
                    +--------------+
                           |
          +----------------+----------------+
          |                |                |
          v                v                v
  Product Service    Face Service    Sentiment Service
          |                |                |
          v                v                v
   Product Model      Face DB       Sentiment Model
          |
          +-----------------------------+
                                        |
                                        v
                                Chatbot Service
                                        |
                                        v
                               Retail Knowledge Base
```

Cross-cutting functionality includes validation, error handling, request
IDs, structured logging, health/readiness checks, dashboard counters,
API documentation, and automated tests.

## 6. Project Structure

``` text
smart_retail_ai/
├── app/
│   ├── api/
│   │   ├── routes_chatbot.py
│   │   ├── routes_dashboard.py
│   │   ├── routes_face.py
│   │   ├── routes_product.py
│   │   └── routes_sentiment.py
│   ├── models/
│   ├── schemas/
│   │   └── api.py
│   ├── services/
│   │   ├── chatbot_service.py
│   │   ├── face_service.py
│   │   ├── product_service.py
│   │   └── sentiment_service.py
│   └── utils/
├── data/
│   ├── faces/
│   ├── products/
│   └── sentiment/
├── models/
│   ├── product_classifier.joblib
│   └── sentiment_classifier.joblib
├── artifacts/
├── scripts/
├── tests/
├── docs/
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── pytest.ini
└── README.md
```

## 7. Product Image Classification

### 7.1 Purpose

The product-classification component predicts a retail product category
from an input image.

Reconstructed classes:

-   Bottle
-   Mug
-   Headphones
-   Shoe

### 7.2 Method

The pipeline is:

``` text
Input Image
    |
    v
Preprocessing
    |
    v
HOG Feature Extraction
    |
    v
RBF-kernel SVM
    |
    v
Product Category
```

HOG provides a compact representation of local image gradients and shape
information. An RBF-kernel SVM performs the final classification.

### 7.3 Evaluation

The controlled reconstructed evaluation produced **100% five-fold
cross-validation accuracy**.

A separate 120-image challenge set included blur, brightness variation,
partial occlusion, resizing, and reflection padding.

  Metric              Challenge Result
  ----------------- ------------------
  Accuracy                       60.0%
  Macro Precision                84.6%
  Macro Recall                   60.0%
  Macro F1                       61.0%
  Samples                          120

The gap demonstrates sensitivity to distribution changes.

### 7.4 API

``` text
POST /classify-product
```

Purpose: accept an image and return a predicted category and confidence.

## 8. Face Verification

### 8.1 Purpose

The face-verification module compares a detected face with a registered
reference.

### 8.2 Method

The reconstructed implementation uses:

-   OpenCV Haar-cascade detection,
-   face crop/normalization,
-   lightweight similarity/template matching,
-   a configurable similarity threshold.

``` text
Input Image
    |
    v
Face Detection
    |
    v
Face Crop
    |
    v
Similarity Calculation
    |
    v
Reference Comparison
    |
    v
Threshold Decision
```

The controlled benchmark used a threshold of approximately **0.52** and
recorded **10/10 correct decisions**.

This is a small educational benchmark and is not sufficient to establish
production biometric performance.

### 8.3 API

``` text
POST /recognize-face
```

## 9. Sentiment Analysis

### 9.1 Purpose

The sentiment model classifies customer text as:

-   Negative
-   Neutral
-   Positive

### 9.2 Method

The reconstructed dataset contains **378 samples**.

Pipeline:

``` text
Customer Text
    |
    v
Normalization
    |
    v
TF-IDF (1-2 grams)
    |
    v
Logistic Regression
    |
    v
Sentiment
```

### 9.3 Controlled Evaluation

  Metric                      Result
  ------------------------- --------
  Samples                        378
  Five-fold mean accuracy     100.0%
  Held-out accuracy           100.0%
  Macro Precision             100.0%
  Macro Recall                100.0%
  Macro F1                    100.0%

### 9.4 Challenge Evaluation

An 18-sample paraphrased challenge set was used.

  Metric              Result
  ----------------- --------
  Accuracy             38.9%
  Macro Precision      26.5%
  Macro Recall         38.9%
  Macro F1             28.5%

This result demonstrates that the controlled dataset was substantially
easier than varied customer language.

### 9.5 API

``` text
POST /analyze-sentiment
```

Example:

``` json
{
  "text": "The delivery was very late and the customer is unhappy."
}
```

Example reconstructed response:

``` json
{
  "sentiment": "negative",
  "confidence": 0.6967
}
```

## 10. Retail Chatbot

The chatbot uses deterministic intent detection and a local retail
knowledge base.

``` text
User Query
    |
    v
Normalization
    |
    v
Intent Detection
    |
    v
Knowledge Base
    |
    v
Structured Response
```

Supported intents include:

-   Greeting
-   Product
-   Order Status
-   Shipping
-   Returns
-   Store Information
-   Payment
-   Support
-   Fallback

Nine representative intent scenarios passed the reconstructed functional
tests.

API:

``` text
POST /chatbot
```

The chatbot is intentionally reproducible and does not require an
external LLM API.

## 11. FastAPI Integration

### API Endpoints

  Method   Endpoint               Purpose
  -------- ---------------------- --------------------------
  GET      `/health`              Application health
  GET      `/health/ready`        Model/artifact readiness
  POST     `/classify-product`    Product classification
  POST     `/recognize-face`      Face verification
  POST     `/analyze-sentiment`   Sentiment analysis
  POST     `/chatbot`             Retail chatbot
  GET      `/dashboard/stats`     Request statistics

### Documentation

FastAPI provides:

``` text
/docs
/redoc
/openapi.json
```

The OpenAPI specification documents the API paths, request schemas, and
responses.

## 12. Validation and Error Handling

Tested cases include:

  Case                         Expected Result
  -------------------------- ---------- --------
  Non-image upload                  400 PASS
  Malformed image                   400 PASS
  Empty image                       400 PASS
  Blank sentiment                   422 PASS
  Blank chatbot message             422 PASS
  Oversized image                   400 PASS
  Overlong chatbot message          422 PASS
  Unknown face                 No match PASS
  Valid request                     200 PASS

## 13. Observability and Dashboard

The platform includes basic request identifiers, structured logging,
processing-time information, and request counters.

``` text
GET /dashboard/stats
```

The dashboard statistics were also checked during end-to-end testing for
consistency with generated API requests.

## 14. Automated Testing

The final reconstructed regression suite reports:

``` text
39 tests
39 passed
```

Tests cover model services, API routes, OpenAPI configuration,
deployment configuration, integration, and end-to-end workflows.

## 15. Robustness Evaluation

The project intentionally separates controlled validation from challenge
evaluation.

  -----------------------------------------------------------------------
  Component                          Controlled                 Challenge
  ------------------- ------------------------- -------------------------
  Product                               100% CV                     60.0%
  Classification                                

  Sentiment Analysis              100% held-out                     38.9%

  Face Verification            10/10 controlled        Not sufficient for
                                                           generalization
  -----------------------------------------------------------------------

The key finding is:

> High controlled validation accuracy does not automatically imply
> real-world generalization.

## 16. End-to-End Evaluation

Five integrated workflows passed:

1.  Product → sentiment → returns chatbot
2.  Face verification → customer support
3.  Product → neutral feedback analysis
4.  Invalid request → validation → recovery
5.  Dashboard request-counter consistency

Result:

``` text
5 / 5 workflows passed
```

This verifies functional integration, not unrestricted real-world model
accuracy.

## 17. Productionization

The reconstructed platform includes:

-   environment-based configuration,
-   request IDs,
-   structured logging,
-   model caching,
-   security-oriented response headers,
-   readiness checks,
-   Dockerfile,
-   Docker Compose configuration.

Security-oriented headers include:

``` text
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Referrer-Policy: no-referrer
```

## 18. Docker Status

Docker configuration was validated, but the reconstruction environment
did not have the Docker CLI installed.

Therefore:

``` text
Docker configuration: VALIDATED
Docker CLI: UNAVAILABLE
Image build: NOT EXECUTED
Container runtime: NOT EXECUTED
```

No successful container deployment is claimed.

## 19. Final Results

  ------------------------------------------------------------------------
  Module                Technique                                   Result
  --------------------- --------------------- ----------------------------
  Product               HOG + RBF SVM               100% controlled; 60.0%
  Classification                                                 challenge

  Face Verification     OpenCV + similarity     10/10 controlled benchmark
                        matching              

  Sentiment Analysis    TF-IDF + Logistic           100% controlled; 38.9%
                        Regression                               challenge

  Retail Chatbot        Deterministic intent                 9/9 scenarios
                        engine                

  API Platform          FastAPI                                39/39 tests

  End-to-End            Integrated workflows                      5/5 pass
  ------------------------------------------------------------------------

## 20. Limitations

1.  The datasets are reconstructed rather than production retail
    datasets.
2.  Product classification is sensitive to distribution shift.
3.  Sentiment analysis has limited robustness to varied language.
4.  Face verification uses a small controlled benchmark.
5.  The chatbot is deterministic rather than LLM-powered.
6.  No live inventory/order database is connected.
7.  No payment processing is implemented.
8.  Docker runtime was not executed.
9.  The evaluation does not represent production-scale traffic.
10. Generated evidence is not original historical internship telemetry.

## 21. Future Scope

-   Use larger real-world product datasets.
-   Apply transfer learning and modern vision models.
-   Expand multilingual and real customer sentiment data.
-   Use stronger face embeddings and liveness detection.
-   Integrate real inventory and order databases.
-   Add LLM/RAG-based conversational support.
-   Add authentication and authorization.
-   Add rate limiting and centralized monitoring.
-   Deploy in a Docker-enabled cloud environment.
-   Implement model drift monitoring and retraining.

## 22. Key Technical Learnings

### Machine Learning

-   supervised classification,
-   feature engineering,
-   cross-validation,
-   model persistence,
-   challenge-set evaluation.

### Computer Vision

-   image preprocessing,
-   HOG features,
-   face detection,
-   similarity matching.

### NLP

-   TF-IDF,
-   n-gram features,
-   text classification,
-   sentiment analysis.

### Software Engineering

-   modular API architecture,
-   schema validation,
-   error handling,
-   logging,
-   automated testing.

### MLOps

-   model artifact management,
-   readiness checks,
-   API documentation,
-   deployment configuration,
-   reproducible evaluation.

## 23. Recommended Final Evidence

For a concise report, the four strongest screenshots are:

1.  Product Classification API --- uploaded image and prediction.
2.  Face Verification --- actual face image, bounding box and match
    result.
3.  Sentiment Analysis API --- request and response.
4.  Pytest --- `39 passed`.

These four provide coverage of the major AI modules and overall system
validation without overloading the report with screenshots.

## 24. Final Project Status

``` text
AI/ML CORE
├── Product Classification        COMPLETE
├── Face Verification             COMPLETE
├── Sentiment Analysis            COMPLETE
└── Retail Chatbot                COMPLETE

API PLATFORM
├── FastAPI Integration           COMPLETE
├── Validation                    COMPLETE
├── Error Handling                COMPLETE
├── Health/Readiness              COMPLETE
├── Dashboard Statistics          COMPLETE
└── OpenAPI Documentation         COMPLETE

EVALUATION
├── Controlled Evaluation         COMPLETE
├── Challenge Evaluation          COMPLETE
├── Automated Testing             39/39 PASS
└── End-to-End Testing            5/5 PASS

DEPLOYMENT
├── Production Configuration      COMPLETE
├── Docker Configuration          COMPLETE
└── Docker Runtime                NOT EXECUTED
```

## 25. Conclusion

The AI-Powered Smart Retail & Customer Intelligence Platform
demonstrates the complete development cycle of a modular AI-enabled
retail service. Product classification, face verification, sentiment
analysis, and chatbot functionality were implemented independently and
integrated through FastAPI.

The project combines computer vision, classical machine learning,
natural-language processing, intent detection, API engineering,
automated testing, robustness evaluation, and deployment preparation.

The most important evaluation finding is the difference between
controlled and challenge performance. The initial perfect controlled
scores were not treated as evidence of generalization. Challenge testing
exposed substantial performance degradation, producing a more defensible
assessment of the reconstructed models.

The final system passed **39/39 automated tests** and **5/5 integrated
workflows**. Docker configuration was validated without claiming an
unexecuted container deployment.

> **Evidence note:** All datasets, metrics, screenshots, model
> artifacts, and evaluation outputs in this documentation are
> reconstructed/re-implemented project evidence unless separately
> supported by original records.
