# Smart Retail AI — API Documentation

## Overview

The Smart Retail AI platform exposes a FastAPI gateway for the reconstructed internship project. Interactive documentation is generated from the application schema.

- Swagger UI: `/docs`
- ReDoc: `/redoc`
- OpenAPI JSON: `/openapi.json`

## Endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | Service health and version |
| GET | `/health/ready` | Required model-artifact readiness |
| POST | `/classify-product` | Classify a retail product image |
| POST | `/recognize-face` | Verify a face against the registered demo face database |
| POST | `/analyze-sentiment` | Classify retail text as negative, neutral, or positive |
| POST | `/chatbot` | Detect retail intent and return a support response |
| GET | `/dashboard/stats` | Return in-process request counters |

## Request formats

### Product and face endpoints
Use `multipart/form-data` with a file field named `file`.

### Sentiment
```json
{"text": "The delivery was very late."}
```

### Chatbot
```json
{"message": "Where is my order?"}
```

## Validation and errors

- Invalid image content is rejected with HTTP 400.
- Empty or malformed image payloads are rejected with HTTP 400.
- Blank or overlong text requests are rejected by Pydantic validation.
- Unexpected service failures return a controlled HTTP 500 response.

## Important evaluation note

This API documentation describes the reconstructed implementation. It should not be presented as evidence that the original historical internship deployment used exactly these routes or runtime configurations unless independently supported by the internship records.
