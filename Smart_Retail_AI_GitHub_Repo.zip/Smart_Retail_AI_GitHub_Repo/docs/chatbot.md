# Retail Chatbot — Part 1, Step 4

## Objective

Implement a reproducible retail customer-assistance component for the AI-Powered Smart Retail & Customer Intelligence Platform.

## Architecture

```text
User message
    ↓
Text normalisation
    ↓
Weighted intent detection
    ↓
Retail knowledge base / response templates
    ↓
Structured response
    ↓
POST /chatbot
```

## Supported intents

- `greeting`
- `products`
- `order_status`
- `shipping`
- `returns`
- `store_info`
- `payment`
- `support`
- `fallback`

The classifier uses deterministic phrase matching with weighted patterns. This was chosen for the reconstruction so that the behaviour is local, explainable, repeatable, and does not require an external LLM or API credential.

## Knowledge base

Retail response content is stored in `data/chatbot/retail_knowledge.json`. The demo explicitly marks store configuration, delivery estimates, catalog coverage, and payment behaviour as reconstruction/demo values where appropriate; it does not connect to live inventory, order systems, payments, or customer records.

## API

`POST /chatbot`

Request:

```json
{"message": "Where is my order?"}
```

Response:

```json
{
  "intent": "order_status",
  "response": "Use the order ID with the order-status service to retrieve the latest shipment state."
}
```

## Evaluation

The step includes a nine-case intent matrix covering greetings, product inquiries, order status, delivery, returns, store information, payment, support, and fallback handling. Additional unit tests verify response schema and case-insensitive matching.

The resulting evaluation is a reconstruction benchmark and should not be described as historical internship telemetry or production chatbot accuracy.
