# Face Recognition Component — Part 1, Step 2

## Scope

This component reconstructs the face-recognition capability described in the internship project specification. The implementation uses OpenCV Haar-cascade face detection followed by a lightweight template-matching stage based on normalized grayscale faces, structural similarity (SSIM), and pixel correlation.

This is a reproducible local demonstration created from the internship-report specification. The evaluation values are newly generated reconstruction results and must not be presented as historical internship measurements.

## Pipeline

1. Load the reference image.
2. Detect the largest face using a Haar cascade.
3. Crop and normalize the detected face to 160 × 160 pixels.
4. Build a local reference template database.
5. Apply the same detection/normalization pipeline to a query image.
6. Compute SSIM and correlation against registered templates.
7. Combine the scores into a similarity score.
8. Compare the score with the configured threshold (0.52).
9. Return match status, person label, similarity and detected bounding box.

## API

`POST /recognize-face`

Input: multipart/form-data image upload.

Example response:

```json
{
  "matched": true,
  "person": "person_01",
  "distance": 0.32,
  "similarity": 0.68,
  "bbox": [13, 10, 105, 105],
  "message": "Face matched"
}
```

## Reconstruction evaluation

The evaluation script runs three cases:

- Reference image — expected match.
- New capture of the same reference subject — expected match.
- Different face image — expected non-match.

The generated evaluation is stored in `artifacts/face/evaluation.json` and the report-ready evidence image is stored in `artifacts/face/face_verification_evidence.png`.

## Safety / scope note

This implementation is intended as a local educational/project demonstration. It is not a biometric identification system for deployment in sensitive environments and should not be used for consequential decisions.
