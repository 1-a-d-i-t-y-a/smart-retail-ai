# Part 1 — Step 1: Product Classification

## Objective
Build and expose a computer-vision product classifier for the reconstructed Smart Retail & Customer Intelligence Platform.

## Classes
- bottle
- mug
- headphones
- shoe

## Approach
1. Generate a reproducible synthetic retail-image dataset.
2. Resize/normalize images and compute HOG descriptors.
3. Train an RBF-kernel SVM with probability estimates.
4. Evaluate on a stratified hold-out test split.
5. Serialize the model with Joblib.
6. Expose inference through `POST /classify-product`.

## Evidence status
This is a reconstructed implementation based on the project description in the internship report. The metrics are measured on the recreated dataset and must not be presented as the original internship metrics.
