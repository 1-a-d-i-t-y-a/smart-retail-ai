# Part 1 — Step 2: Face Recognition

## Purpose

Recreate the face-recognition capability documented in the internship project specification as a reproducible local demonstration.

## Method

- Detect the largest frontal face with OpenCV Haar cascade.
- Normalize the detected face to a fixed 160×160 grayscale representation.
- Equalize the histogram to reduce illumination differences.
- Compare the query face with the registered template using structural similarity and correlation.
- Accept a match when the combined similarity is at least 0.52.

## Evaluation cases

1. Registered reference image — expected match.
2. Mildly transformed new capture generated from the registered reference — expected match.
3. Separate face image used as a non-match control — expected no match.

## Important reporting note

These results are reconstructed project evidence generated during re-implementation. They are not the original internship-time accuracy figures.
