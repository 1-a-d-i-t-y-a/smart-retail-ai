# Part 1 — Step 3: Sentiment Analysis

## Objective
Implement the natural-language-processing component of the reconstructed Smart Retail & Customer Intelligence Platform. The component classifies customer/retail text into positive, neutral, or negative sentiment and exposes the model through FastAPI.

## Methodology
1. Generate a reproducible, labeled retail-sentiment dataset.
2. Split the dataset into stratified training and held-out test sets.
3. Convert text into TF-IDF features using word unigrams and bigrams.
4. Train a Logistic Regression classifier.
5. Evaluate using accuracy, precision, recall, F1-score, and a confusion matrix.
6. Serialize the complete preprocessing/model pipeline with Joblib.
7. Expose inference through `POST /analyze-sentiment`.

## Reconstructed dataset
- Total samples: 378
- Training samples: 283
- Held-out test samples: 95
- Classes: negative, neutral, positive

## Reconstructed evaluation
- Accuracy: 100% on the controlled held-out dataset.
- All 95 held-out examples were classified correctly.
- Confusion matrix is diagonal: 31 negative, 32 neutral, and 32 positive test examples were correctly classified.

## API
`POST /analyze-sentiment`

Request:
```json
{"text": "The delivery was very late and the customer is unhappy."}
```

Response shape:
```json
{"sentiment": "negative", "confidence": 0.69}
```

## Evidence generated
- `artifacts/sentiment/metrics.json`
- `artifacts/sentiment/confusion_matrix.png`
- `artifacts/sentiment/classification_report.png`
- `artifacts/sentiment/inference_examples.csv`
- `artifacts/sentiment/sentiment_analysis_evidence.png`
- `artifacts/sentiment/evaluation_summary.json`

## Interpretation note
These metrics come from a newly reconstructed, controlled dataset created to make the project reproducible. They are not historical internship measurements and must not be presented as original internship performance.
