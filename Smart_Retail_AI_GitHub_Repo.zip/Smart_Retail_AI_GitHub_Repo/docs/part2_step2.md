# Part 2 — Step 2: Robust Model Evaluation

## Purpose

The initial evaluation produced 100% scores on controlled/reconstructed data. Because such results can be overly optimistic, this step adds deliberately harder challenge holdouts and separates **in-distribution validation** from **generalization stress testing**.

## Product classification

- Baseline: 5-fold stratified cross-validation on the reconstructed generated dataset.
- Challenge set: independently generated images using a new random seed with blur, brightness shifts, partial occlusion, resizing and reflection-padding transformations.
- The challenge set is not used to train the deployed model.

## Sentiment analysis

- Baseline: 5-fold stratified cross-validation plus the existing held-out split.
- Challenge set: 18 hand-written, paraphrased retail statements designed to avoid direct template overlap and include less explicit sentiment language.
- The challenge set is not used for training.

## Face verification

The available reconstruction contains one registered positive identity and one negative comparison identity. Therefore the face experiment remains a **controlled robustness stress test**, not a statistically meaningful biometric generalization study. It uses perturbations such as noise and blur and reports the limitation explicitly.

## Interpretation

The 100% in-distribution scores are retained as baseline reconstruction metrics, but they are **not** used as the project's primary generalization claim. The challenge results are reported separately to expose distribution-shift sensitivity.

These are reconstructed project metrics and are not original historical internship telemetry.
