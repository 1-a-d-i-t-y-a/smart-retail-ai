# Sentiment Analysis Component

The sentiment-analysis service uses a scikit-learn Pipeline containing TF-IDF vectorization with 1–2 gram features and Logistic Regression. The trained pipeline is stored as `models/sentiment_classifier.joblib` and loaded by the FastAPI service at inference time.

### Endpoint
`POST /analyze-sentiment`

### Input
A JSON object with a non-empty `text` field.

### Output
The service returns the predicted sentiment label and the highest class probability as a confidence value.

### Classes
- `positive`
- `neutral`
- `negative`

### Reproducibility
Run:
```bash
python scripts/build_sentiment_model.py
python scripts/generate_sentiment_evidence.py
pytest -q
```

The generated evidence is based on the reconstructed project and controlled retail-sentiment dataset.
