from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]

if __name__ == "__main__":
    scripts = [
        ROOT / "scripts" / "build_product_model.py",
        ROOT / "scripts" / "build_sentiment_model.py",
        ROOT / "scripts" / "build_face_db.py",
    ]
    for script in scripts:
        subprocess.run([sys.executable, str(script)], cwd=ROOT, check=True)
    print("All Part 1 models built successfully.")
