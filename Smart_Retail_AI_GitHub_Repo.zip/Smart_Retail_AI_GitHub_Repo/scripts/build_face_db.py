from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.services.face_service import build_face_db

build_face_db(ROOT / "data" / "faces" / "person_01_reference.png")
print("Face database rebuilt successfully.")
