from __future__ import annotations

import json
from pathlib import Path

import cv2
import joblib
import numpy as np
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data" / "products"
MODEL_DIR = ROOT / "models"
ART_DIR = ROOT / "artifacts"

CLASSES = ["bottle", "mug", "headphones", "shoe"]
IMG_SIZE = 128


def draw_product(label: str, rng: np.random.Generator) -> np.ndarray:
    img = np.full((IMG_SIZE, IMG_SIZE, 3), 245, np.uint8)
    # subtle background texture
    noise = rng.normal(0, 4, img.shape).astype(np.int16)
    img = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)
    color = tuple(int(x) for x in rng.integers(40, 220, size=3))
    black = (25, 25, 25)

    if label == "bottle":
        x = int(rng.integers(45, 60)); y = int(rng.integers(22, 35)); w = int(rng.integers(28, 38)); h = int(rng.integers(70, 85))
        cv2.rectangle(img, (x + 6, y), (x + w - 6, y + h), color, -1)
        cv2.ellipse(img, (x + 6, y + 6), (6, 6), 0, 90, 180, color, -1)
        cv2.ellipse(img, (x + w - 6, y + 6), (6, 6), 0, 0, 90, color, -1)
        cv2.ellipse(img, (x + 6, y + h - 6), (6, 6), 0, 180, 270, color, -1)
        cv2.ellipse(img, (x + w - 6, y + h - 6), (6, 6), 0, 270, 360, color, -1)
        cv2.rectangle(img, (x + 8, y - 8), (x + w - 8, y + 3), black, -1)
    elif label == "mug":
        x = int(rng.integers(30, 45)); y = int(rng.integers(45, 60)); w = int(rng.integers(45, 58)); h = int(rng.integers(38, 50))
        cv2.rectangle(img, (x, y), (x + w, y + h), color, -1)
        cv2.ellipse(img, (x + w, y + h // 2), (16, 20), 0, -90, 90, color, 8)
        cv2.ellipse(img, (x + w // 2, y), (w // 2 - 4, 7), 0, 0, 360, black, 2)
    elif label == "headphones":
        center = (64, 63); axes = (35, 42)
        cv2.ellipse(img, center, axes, 0, 180, 360, black, 8)
        cv2.rectangle(img, (25, 56), (40, 88), color, -1)
        cv2.rectangle(img, (88, 56), (103, 88), color, -1)
        cv2.circle(img, (32, 73), 10, color, -1)
        cv2.circle(img, (96, 73), 10, color, -1)
    else:  # shoe
        pts = np.array([[22, 83], [53, 78], [73, 52], [91, 58], [88, 73], [112, 78], [107, 98], [30, 99]], np.int32)
        cv2.fillPoly(img, [pts], color)
        cv2.line(img, (34, 86), (78, 77), black, 4)
        cv2.line(img, (48, 91), (88, 82), black, 4)

    # small random perspective-ish transforms
    angle = float(rng.uniform(-8, 8))
    scale = float(rng.uniform(0.92, 1.06))
    M = cv2.getRotationMatrix2D((64, 64), angle, scale)
    img = cv2.warpAffine(img, M, (IMG_SIZE, IMG_SIZE), borderValue=(245, 245, 245))
    return img


def features(img: np.ndarray) -> np.ndarray:
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    hog = cv2.HOGDescriptor(_winSize=(128, 128), _blockSize=(32, 32), _blockStride=(16, 16), _cellSize=(16, 16), _nbins=9)
    return hog.compute(gray).reshape(-1)


def make_dataset() -> tuple[np.ndarray, np.ndarray]:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(42)
    X, y = [], []
    for idx, label in enumerate(CLASSES):
        class_dir = DATA_DIR / label
        class_dir.mkdir(parents=True, exist_ok=True)
        for i in range(75):
            img = draw_product(label, rng)
            path = class_dir / f"{label}_{i:03d}.png"
            cv2.imwrite(str(path), img)
            X.append(features(img))
            y.append(idx)
    return np.asarray(X), np.asarray(y)


def train() -> None:
    MODEL_DIR.mkdir(exist_ok=True)
    (ART_DIR / "product").mkdir(parents=True, exist_ok=True)
    X, y = make_dataset()
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
    pipe = Pipeline([
        ("scaler", StandardScaler()),
        ("clf", SVC(kernel="rbf", probability=True, random_state=42)),
    ])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    metrics = {
        "accuracy": float(accuracy_score(y_test, pred)),
        "classification_report": classification_report(y_test, pred, target_names=CLASSES, output_dict=True),
        "confusion_matrix": confusion_matrix(y_test, pred).tolist(),
        "classes": CLASSES,
        "train_samples": int(len(X_train)),
        "test_samples": int(len(X_test)),
    }
    joblib.dump({"pipeline": pipe, "classes": CLASSES}, MODEL_DIR / "product_classifier.joblib")
    (ART_DIR / "product" / "metrics.json").write_text(json.dumps(metrics, indent=2))
    print(f"Product classifier trained. Accuracy={metrics['accuracy']:.4f}")


if __name__ == "__main__":
    train()
