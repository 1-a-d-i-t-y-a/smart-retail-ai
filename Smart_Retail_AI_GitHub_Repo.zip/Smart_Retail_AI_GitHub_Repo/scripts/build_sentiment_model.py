from __future__ import annotations

import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data" / "sentiment"
MODEL_DIR = ROOT / "models"
ART_DIR = ROOT / "artifacts" / "sentiment"

BASE = {
    "positive": [
        "excellent product quality", "great customer service", "fast delivery", "amazing value for money",
        "beautiful design", "very happy with the purchase", "fantastic shopping experience", "easy to use",
        "highly recommend this product", "the packaging was excellent", "support solved my issue quickly",
        "the headphones sound fantastic", "the product feels premium", "delivery was quick and safe",
        "the app is smooth and useful", "I love this product", "the quality is outstanding", "very satisfied customer",
    ],
    "negative": [
        "poor product quality", "terrible customer service", "delivery was very late", "bad value for money",
        "disappointing design", "very unhappy with the purchase", "awful shopping experience", "difficult to use",
        "I would not recommend this product", "the packaging was damaged", "support did not solve my issue",
        "the headphones sound terrible", "the product feels cheap", "delivery was slow and unsafe",
        "the app is buggy and confusing", "I regret this purchase", "the quality is disappointing", "very dissatisfied customer",
    ],
    "neutral": [
        "the product is available online", "the store opens at ten", "the package arrived Tuesday",
        "the item comes in three sizes", "this model has a one year warranty", "the order contains two products",
        "the new version was released this month", "the delivery address was updated", "the item is listed in the catalog",
        "the store is located in the city center", "the product is available in black", "the order status was updated",
        "the package weight is two kilograms", "the model number is listed on the box", "the store has five counters",
        "the item is currently in stock", "the warranty starts on the purchase date", "the shipment contains one parcel",
    ],
}


def generate_rows() -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    prefixes = ["I think", "In my experience", "Overall", "For me", "The customer says", "The shopper says"]
    suffixes = [".", " today.", " in this store.", " with this order."]
    for label, sentences in BASE.items():
        for sentence in sentences:
            rows.append((label, sentence + "." if not sentence.endswith(".") else sentence))
            for p in prefixes[:3]:
                for s in suffixes[:2]:
                    rows.append((label, f"{p}, {sentence}{s}"))
    return rows


def train() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    ART_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(generate_rows(), columns=["label", "text"]).drop_duplicates()
    df.to_csv(DATA_DIR / "retail_sentiment.csv", index=False)
    X_train, X_test, y_train, y_test = train_test_split(
        df["text"], df["label"], test_size=0.25, stratify=df["label"], random_state=42
    )
    pipe = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), lowercase=True, sublinear_tf=True)),
        ("clf", LogisticRegression(max_iter=2000, random_state=42)),
    ])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    metrics = {
        "accuracy": float(accuracy_score(y_test, pred)),
        "classification_report": classification_report(y_test, pred, output_dict=True),
        "confusion_matrix": confusion_matrix(y_test, pred, labels=["negative", "neutral", "positive"]).tolist(),
        "classes": ["negative", "neutral", "positive"],
        "train_samples": int(len(X_train)),
        "test_samples": int(len(X_test)),
    }
    joblib.dump(pipe, MODEL_DIR / "sentiment_classifier.joblib")
    (ART_DIR / "metrics.json").write_text(json.dumps(metrics, indent=2))
    print(f"Sentiment classifier trained. Accuracy={metrics['accuracy']:.4f}; samples={len(df)}")


if __name__ == "__main__":
    train()
