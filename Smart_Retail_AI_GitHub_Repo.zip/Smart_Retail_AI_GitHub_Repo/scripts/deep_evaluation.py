from __future__ import annotations

import json
from pathlib import Path

import cv2
import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    precision_recall_fscore_support,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

from app.services.face_service import build_face_db, recognize_face

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / "artifacts" / "evaluation"
ART.mkdir(parents=True, exist_ok=True)


def product_eval() -> dict:
    from scripts.build_product_model import make_dataset, CLASSES
    X, y = make_dataset()
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    pipe = Pipeline([
        ("scaler", StandardScaler()),
        ("clf", SVC(kernel="rbf", probability=True, random_state=42)),
    ])
    scores = cross_val_score(pipe, X, y, cv=cv, scoring="accuracy")
    pipe.fit(X, y)

    # Harder holdout: independently generated images with stronger visual corruption.
    from scripts.build_product_model import draw_product, features
    rng = np.random.default_rng(999)
    X_ch, y_ch = [], []
    for idx, label in enumerate(CLASSES):
        for i in range(30):
            img = draw_product(label, rng)
            if i % 3 == 0:
                img = cv2.GaussianBlur(img, (5, 5), 0)
            elif i % 3 == 1:
                img = np.clip(img.astype(np.int16) + rng.integers(-35, 36), 0, 255).astype(np.uint8)
            if i % 4 == 0:
                h = int(rng.integers(10, 36)); w = int(rng.integers(10, 36))
                cv2.rectangle(img, (0, 0), (w, h), (100, 100, 100), -1)
            if i % 5 == 0:
                img = cv2.resize(img, (96, 96))
                img = cv2.copyMakeBorder(img, 16, 16, 16, 16, cv2.BORDER_REFLECT)
            X_ch.append(features(img)); y_ch.append(idx)
    ch_pred = pipe.predict(X_ch)
    ch_report = classification_report(y_ch, ch_pred, target_names=CLASSES, output_dict=True)

    return {
        "dataset_samples": int(len(y)),
        "classes": CLASSES,
        "cross_validation": {
            "folds": 5,
            "scores": [float(x) for x in scores],
            "mean_accuracy": float(scores.mean()),
            "std_accuracy": float(scores.std()),
        },
        "challenge_holdout": {
            "samples": int(len(y_ch)),
            "accuracy": float(accuracy_score(y_ch, ch_pred)),
            "macro_precision": float(ch_report["macro avg"]["precision"]),
            "macro_recall": float(ch_report["macro avg"]["recall"]),
            "macro_f1": float(ch_report["macro avg"]["f1-score"]),
            "confusion_matrix": confusion_matrix(y_ch, ch_pred).tolist(),
            "classification_report": ch_report,
            "description": "Independently generated images using a new random seed plus blur, brightness shifts, partial occlusion, resize and reflection-padding transformations.",
        },
        "note": "The 5-fold result is a controlled reconstruction benchmark. The challenge holdout is intentionally harder and is used to probe generalization beyond the simple generated training distribution; neither result is an original internship metric.",
    }

def sentiment_eval() -> dict:
    from scripts.build_sentiment_model import generate_rows
    df = pd.DataFrame(generate_rows(), columns=["label", "text"]).drop_duplicates()
    X, y = df["text"], df["label"]
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    pipe = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), lowercase=True, sublinear_tf=True)),
        ("clf", LogisticRegression(max_iter=2000, random_state=42)),
    ])
    scores = cross_val_score(pipe, X, y, cv=cv, scoring="accuracy")
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=42)
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    proba = pipe.predict_proba(X_test)
    labels = ["negative", "neutral", "positive"]
    p, r, f, support = precision_recall_fscore_support(y_test, pred, labels=labels, zero_division=0)

    challenge = {
        "positive": [
            "The item arrived sooner than the tracking estimate and feels sturdier than expected",
            "Nothing about the checkout or delivery caused trouble and I would purchase here again",
            "The replacement was handled promptly and the new unit works perfectly",
            "Packaging was secure, the finish looks premium, and the price felt justified",
            "I was pleasantly surprised by how responsive the support team was",
            "The product exceeded what I expected from the listing",
        ],
        "negative": [
            "The item looked acceptable online but the delivered unit feels flimsy and poorly made",
            "I had to contact support twice and the issue is still unresolved",
            "The promised delivery window passed before the parcel even left the warehouse",
            "The refund process has been frustrating and I am still waiting for the money",
            "The device stopped working shortly after arrival and the replacement was delayed",
            "The price would have been reasonable if the product had matched the description",
        ],
        "neutral": [
            "The order was placed yesterday and the tracking page now shows it in transit",
            "The package contains the black version with a one year warranty",
            "The store currently lists this model in two sizes",
            "The delivery address was changed before the shipment was dispatched",
            "The order contains one headphone set and two accessories",
            "The product page states that the item is currently available online",
        ],
    }
    c_text, c_y = [], []
    for label, rows in challenge.items():
        for text in rows:
            c_text.append(text); c_y.append(label)
    c_pred = pipe.predict(c_text)
    c_report = classification_report(c_y, c_pred, labels=labels, output_dict=True, zero_division=0)

    return {
        "dataset_samples": int(len(df)),
        "classes": labels,
        "cross_validation": {
            "folds": 5,
            "scores": [float(x) for x in scores],
            "mean_accuracy": float(scores.mean()),
            "std_accuracy": float(scores.std()),
        },
        "held_out_metrics": {
            "accuracy": float(accuracy_score(y_test, pred)),
            "macro_precision": float(p.mean()),
            "macro_recall": float(r.mean()),
            "macro_f1": float(f.mean()),
            "mean_max_probability": float(proba.max(axis=1).mean()),
            "confusion_matrix": confusion_matrix(y_test, pred, labels=labels).tolist(),
            "class_support": {labels[i]: int(support[i]) for i in range(len(labels))},
        },
        "challenge_holdout": {
            "samples": int(len(c_y)),
            "accuracy": float(accuracy_score(c_y, c_pred)),
            "macro_precision": float(c_report["macro avg"]["precision"]),
            "macro_recall": float(c_report["macro avg"]["recall"]),
            "macro_f1": float(c_report["macro avg"]["f1-score"]),
            "confusion_matrix": confusion_matrix(c_y, c_pred, labels=labels).tolist(),
            "classification_report": c_report,
            "description": "Hand-written paraphrased retail statements designed to avoid template overlap and include indirect, mixed-context and less explicit sentiment wording.",
        },
        "note": "The standard split/CV results are controlled reconstruction benchmarks. The challenge holdout intentionally probes language generalization and demonstrates that high in-distribution scores do not imply unrestricted customer-language accuracy.",
    }

def face_variants() -> dict:
    face_dir = ROOT / "data" / "faces"
    ref = face_dir / "person_01_reference.png"
    pos = cv2.imread(str(face_dir / "person_01_query.png"))
    neg = cv2.imread(str(face_dir / "negative_astronaut.png"))
    if pos is None or neg is None:
        raise RuntimeError("Face evaluation images unavailable")
    rng = np.random.default_rng(42)
    variants = []
    # Controlled perturbations of the positive query.
    for i, sigma in enumerate([0, 3, 6, 10, 15]):
        img = pos.copy()
        if sigma:
            noise = rng.normal(0, sigma, img.shape).astype(np.float32)
            img = np.clip(img.astype(np.float32) + noise, 0, 255).astype(np.uint8)
        if i in {2, 4}:
            img = cv2.GaussianBlur(img, (3, 3), 0)
        ok, enc = cv2.imencode(".png", img)
        if ok:
            variants.append((f"positive_noise_{sigma}", enc.tobytes(), True))
    # Controlled perturbations of the negative face.
    for i, sigma in enumerate([0, 3, 6, 10, 15]):
        img = neg.copy()
        if sigma:
            noise = rng.normal(0, sigma, img.shape).astype(np.float32)
            img = np.clip(img.astype(np.float32) + noise, 0, 255).astype(np.uint8)
        if i in {2, 4}:
            img = cv2.GaussianBlur(img, (3, 3), 0)
        ok, enc = cv2.imencode(".png", img)
        if ok:
            variants.append((f"negative_noise_{sigma}", enc.tobytes(), False))
    build_face_db(ref, threshold=0.52)
    results = []
    for name, data, expected in variants:
        r = recognize_face(data)
        r.update({"case": name, "expected_match": expected, "correct": bool(r["matched"] == expected)})
        results.append(r)
    scored = [r for r in results if r.get("similarity") is not None]
    y_true = np.array([int(r["expected_match"]) for r in scored])
    scores = np.array([float(r["similarity"]) for r in scored])
    auc = float(roc_auc_score(y_true, scores)) if len(np.unique(y_true)) == 2 else None
    thresholds = []
    for t in np.arange(0.40, 0.81, 0.02):
        pred = scores >= t
        acc = float((pred == y_true).mean())
        tp = int(((pred == 1) & (y_true == 1)).sum())
        fn = int(((pred == 0) & (y_true == 1)).sum())
        fp = int(((pred == 1) & (y_true == 0)).sum())
        tn = int(((pred == 0) & (y_true == 0)).sum())
        tpr = tp / (tp + fn) if tp + fn else 0.0
        fpr = fp / (fp + tn) if fp + tn else 0.0
        thresholds.append({"threshold": round(float(t), 2), "accuracy": acc, "tpr": tpr, "fpr": fpr})
    best = max(thresholds, key=lambda x: (x["accuracy"], -x["fpr"]))
    payload = {
        "cases": len(results),
        "correct": int(sum(r["correct"] for r in results)),
        "accuracy_at_0_52": float(sum(r["correct"] for r in results) / len(results)),
        "roc_auc": auc,
        "similarity_range": {"min": float(scores.min()), "max": float(scores.max()), "mean": float(scores.mean())},
        "threshold_sweep": thresholds,
        "selected_operating_threshold": 0.52,
        "best_threshold_on_controlled_set": best,
        "results": results,
        "note": "Controlled perturbation benchmark for the lightweight reconstructed face-verification demo; not a biometric validation study or an original internship metric.",
    }
    return payload


def evidence(product: dict, sentiment: dict, face: dict) -> None:
    fig = plt.figure(figsize=(15, 10))
    ax = fig.add_axes([0.05, 0.06, 0.9, 0.88])
    ax.axis("off")
    lines = [
        "SMART RETAIL AI — ROBUST MODEL EVALUATION",
        "Reconstructed Project Evidence",
        "",
        f"Product | In-distribution 5-fold CV: {product['cross_validation']['mean_accuracy']:.3f} ± {product['cross_validation']['std_accuracy']:.3f} | Challenge holdout: {product['challenge_holdout']['accuracy']:.3f} | N={product['challenge_holdout']['samples']}",
        f"Sentiment | In-distribution 5-fold CV: {sentiment['cross_validation']['mean_accuracy']:.3f} ± {sentiment['cross_validation']['std_accuracy']:.3f} | Challenge holdout: {sentiment['challenge_holdout']['accuracy']:.3f} | N={sentiment['challenge_holdout']['samples']}",
        f"Face | Controlled perturbation test: {face['correct']}/{face['cases']} correct | threshold={face['selected_operating_threshold']}",
        "",
        "Interpretation: the controlled 100% scores are not treated as proof of generalization. Challenge holdouts are deliberately harder and are reported separately.",
        "All metrics are reconstructed project evidence, not historical internship telemetry.",
    ]
    y = 0.95
    for i, line in enumerate(lines):
        ax.text(0.02, y, line, fontsize=19 if i == 0 else 12, fontweight="bold" if i == 0 else "normal", va="top")
        y -= 0.095 if i == 0 else 0.09
    out = ART / "model_evaluation_evidence.png"
    fig.savefig(out, dpi=180, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    product = product_eval()
    sentiment = sentiment_eval()
    face = face_variants()
    payload = {"product": product, "sentiment": sentiment, "face": face}
    (ART / "model_evaluation.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    evidence(product, sentiment, face)
    print(json.dumps({
        "product_cv_mean": product["cross_validation"]["mean_accuracy"],
        "product_cv_std": product["cross_validation"]["std_accuracy"],
        "product_challenge_accuracy": product["challenge_holdout"]["accuracy"],
        "sentiment_cv_mean": sentiment["cross_validation"]["mean_accuracy"],
        "sentiment_cv_std": sentiment["cross_validation"]["std_accuracy"],
        "sentiment_challenge_accuracy": sentiment["challenge_holdout"]["accuracy"],
        "face_accuracy": face["accuracy_at_0_52"],
        "face_auc": face["roc_auc"],
        "face_best_controlled_threshold": face["best_threshold_on_controlled_set"],
    }, indent=2))


if __name__ == "__main__":
    main()
