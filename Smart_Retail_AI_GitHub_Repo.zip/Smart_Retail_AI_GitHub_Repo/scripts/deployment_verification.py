from __future__ import annotations
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / "artifacts" / "deployment"
ART.mkdir(parents=True, exist_ok=True)

checks = {}
checks["dockerfile_exists"] = (ROOT / "Dockerfile").exists()
checks["compose_exists"] = (ROOT / "docker-compose.yml").exists()
checks["env_example_exists"] = (ROOT / ".env.example").exists()
checks["docker_cli_available"] = shutil.which("docker") is not None

if checks["docker_cli_available"]:
    p = subprocess.run(["docker", "--version"], capture_output=True, text=True)
    checks["docker_version"] = p.stdout.strip() or p.stderr.strip()
    build = subprocess.run(["docker", "build", "-t", "smart-retail-ai:step4", "."], cwd=ROOT, capture_output=True, text=True)
    checks["docker_build"] = build.returncode == 0
    checks["docker_build_output_tail"] = (build.stdout + build.stderr)[-2000:]
else:
    checks["docker_build"] = False
    checks["docker_build_output_tail"] = "Docker CLI unavailable in execution environment; build not executed."

checks["deployment_configuration_validated"] = all(checks[k] for k in ["dockerfile_exists", "compose_exists", "env_example_exists"])
checks["overall_runtime_status"] = "runtime_not_executed" if not checks["docker_cli_available"] else ("build_passed" if checks["docker_build"] else "build_failed")

(ART / "deployment_verification.json").write_text(json.dumps(checks, indent=2))
print(json.dumps(checks, indent=2))
