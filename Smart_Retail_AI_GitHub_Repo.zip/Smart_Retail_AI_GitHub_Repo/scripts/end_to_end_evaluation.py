from __future__ import annotations
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
from app.main import app

ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'artifacts'/'end_to_end'; ART.mkdir(parents=True, exist_ok=True)


def run():
    c=TestClient(app)
    before=c.get('/dashboard/stats').json()
    product=ROOT/'data/products/bottle/bottle_000.png'
    face=ROOT/'data/faces/person_01_query.png'
    checks=[]

    # Workflow A: product -> sentiment -> chatbot
    with product.open('rb') as f: rp=c.post('/classify-product', files={'file':(product.name,f,'image/png')})
    rs=c.post('/analyze-sentiment', json={'text':'The bottle arrived late and the customer is unhappy.'})
    rc=c.post('/chatbot', json={'message':'How can I return this product?'})
    checks.append({'workflow':'product_customer_issue','passed':rp.status_code==200 and rs.status_code==200 and rc.status_code==200,
                   'product':rp.json(),'sentiment':rs.json(),'chatbot':rc.json()})

    # Workflow B: face verification -> support
    with face.open('rb') as f: rf=c.post('/recognize-face', files={'file':(face.name,f,'image/png')})
    rc2=c.post('/chatbot', json={'message':'I need customer support for my order.'})
    checks.append({'workflow':'customer_identity_support','passed':rf.status_code==200 and rc2.status_code==200,
                   'face':rf.json(),'chatbot':rc2.json()})

    # Workflow C: neutral product experience
    rp2=None
    with product.open('rb') as f: rp2=c.post('/classify-product', files={'file':(product.name,f,'image/png')})
    rs2=c.post('/analyze-sentiment', json={'text':'The product is okay and the delivery was on time.'})
    checks.append({'workflow':'product_neutral_feedback','passed':rp2.status_code==200 and rs2.status_code==200,
                   'product':rp2.json(),'sentiment':rs2.json()})

    # Workflow D: invalid request containment, then recovery
    bad=c.post('/analyze-sentiment', json={'text':''})
    good=c.post('/chatbot', json={'message':'What payment methods do you accept?'})
    checks.append({'workflow':'validation_and_recovery','passed':bad.status_code==422 and good.status_code==200,
                   'invalid_status':bad.status_code,'recovery':good.json()})

    after=c.get('/dashboard/stats').json()
    delta={k:after[k]-before[k] for k in after}
    expected={'total_requests':8,'product_requests':2,'face_requests':1,'sentiment_requests':2,'chatbot_requests':3}
    checks.append({'workflow':'dashboard_consistency','passed':delta==expected,'delta':delta,'expected':expected})
    passed=sum(bool(x['passed']) for x in checks)
    summary={'evaluation':'end_to_end_system','passed':passed,'total':len(checks),'all_passed':passed==len(checks),
             'checks':checks,'note':'Reconstructed end-to-end evaluation; results are not original historical internship telemetry.'}
    (ART/'end_to_end_evaluation.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
    if not summary['all_passed']: raise SystemExit(1)

if __name__=='__main__': run()
