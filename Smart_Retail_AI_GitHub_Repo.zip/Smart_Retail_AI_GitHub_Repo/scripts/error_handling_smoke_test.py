from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def run() -> dict:
    checks = []

    cases = [
        ("product_non_image", lambda: client.post("/classify-product", files={"file": ("x.txt", b"x", "text/plain")} ), 400),
        ("product_malformed_image", lambda: client.post("/classify-product", files={"file": ("x.png", b"broken", "image/png")} ), 400),
        ("face_empty_image", lambda: client.post("/recognize-face", files={"file": ("x.png", b"", "image/png")} ), 400),
        ("sentiment_blank", lambda: client.post("/analyze-sentiment", json={"text": "   "}), 422),
        ("chatbot_blank", lambda: client.post("/chatbot", json={"message": "   "}), 422),
        ("chatbot_overlong", lambda: client.post("/chatbot", json={"message": "x" * 2001}), 422),
        ("product_oversized_image", lambda: client.post("/classify-product", files={"file": ("large.png", b"0" * (5 * 1024 * 1024 + 1), "image/png")}), 400),
    ]

    for name, call, expected in cases:
        response = call()
        passed = response.status_code == expected
        checks.append({"name": name, "expected_status": expected, "actual_status": response.status_code, "passed": passed})

    face = ROOT / "data" / "faces" / "negative_astronaut.png"
    response = client.post("/recognize-face", files={"file": (face.name, face.read_bytes(), "image/png")})
    checks.append({"name": "face_without_match", "expected_status": 200, "actual_status": response.status_code, "matched": response.json().get("matched"), "passed": response.status_code == 200 and response.json().get("matched") is False})

    product = ROOT / "data" / "products" / "bottle" / "bottle_000.png"
    response = client.post("/classify-product", files={"file": (product.name, product.read_bytes(), "image/png")})
    checks.append({"name": "valid_product_image", "expected_status": 200, "actual_status": response.status_code, "product": response.json().get("product"), "passed": response.status_code == 200})

    return {"step": "Step 6 - Initial System Testing & Error Handling", "checks": checks, "passed": sum(c["passed"] for c in checks), "total": len(checks), "all_passed": all(c["passed"] for c in checks)}


if __name__ == "__main__":
    result = run()
    out = ROOT / "artifacts" / "testing"
    out.mkdir(parents=True, exist_ok=True)
    (out / "error_handling_smoke.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
