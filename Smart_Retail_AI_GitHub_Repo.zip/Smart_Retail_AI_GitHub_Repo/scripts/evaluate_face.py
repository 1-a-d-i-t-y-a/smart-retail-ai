from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np

from app.services.face_service import build_face_db, recognize_face

ROOT = Path(__file__).resolve().parents[1]
FACE_DIR = ROOT / "data" / "faces"
OUT_DIR = ROOT / "artifacts" / "face"
OUT_DIR.mkdir(parents=True, exist_ok=True)

REFERENCE = FACE_DIR / "person_01_reference.png"
POSITIVE = FACE_DIR / "person_01_query.png"
NEGATIVE = FACE_DIR / "negative_astronaut.png"


def annotate(image_path: Path, result: dict, out_path: Path, label: str) -> None:
    image = cv2.imread(str(image_path))
    if image is None:
        raise FileNotFoundError(image_path)
    bbox = result.get("bbox")
    if bbox:
        x, y, w, h = bbox
        cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0) if result.get("matched") else (0, 0, 255), 2)
    sim = result.get("similarity")
    score = "n/a" if sim is None else f"{sim:.3f}"
    status = "MATCH" if result.get("matched") else "NO MATCH"
    text = f"{label} | {status} | similarity={score}"
    cv2.rectangle(image, (0, 0), (image.shape[1], 34), (20, 20, 20), -1)
    cv2.putText(image, text, (8, 23), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)
    cv2.imwrite(str(out_path), image)


def main() -> None:
    build_face_db(REFERENCE, threshold=0.52)
    cases = [
        ("reference", REFERENCE, True),
        ("positive_query", POSITIVE, True),
        ("negative_other_face", NEGATIVE, False),
    ]
    results = []
    for name, path, expected in cases:
        result = recognize_face(path.read_bytes())
        result["case"] = name
        result["expected_match"] = expected
        result["correct"] = bool(result["matched"] == expected)
        results.append(result)
        annotate(path, result, OUT_DIR / f"{name}_annotated.png", name)

    accuracy = sum(int(r["correct"]) for r in results) / len(results)
    positive_scores = [r["similarity"] for r in results if r["expected_match"] and r["similarity"] is not None]
    negative_scores = [r["similarity"] for r in results if not r["expected_match"] and r["similarity"] is not None]

    payload = {
        "metrics": {
            "cases": len(results),
            "correct": sum(int(r["correct"]) for r in results),
            "accuracy": accuracy,
            "threshold": 0.52,
            "mean_positive_similarity": float(np.mean(positive_scores)) if positive_scores else None,
            "mean_negative_similarity": float(np.mean(negative_scores)) if negative_scores else None,
            "note": "Reconstructed face-verification demonstration using OpenCV Haar detection plus structural-similarity/correlation matching; not an original internship metric.",
        },
        "results": results,
    }
    (OUT_DIR / "evaluation.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    # Compact comparison figure for the internship report.
    canvases = []
    for name in ["reference", "positive_query", "negative_other_face"]:
        canvases.append(cv2.imread(str(OUT_DIR / f"{name}_annotated.png")))
    target_h = 320
    resized = []
    for im in canvases:
        scale = target_h / im.shape[0]
        resized.append(cv2.resize(im, (int(im.shape[1] * scale), target_h)))
    canvas = cv2.hconcat(resized)
    cv2.imwrite(str(OUT_DIR / "face_verification_evidence.png"), canvas)
    print(json.dumps(payload["metrics"], indent=2))


if __name__ == "__main__":
    main()
