from __future__ import annotations

import json
from pathlib import Path

from app.main import app

root = Path(__file__).resolve().parents[1]
out = root / "artifacts" / "api"
out.mkdir(parents=True, exist_ok=True)

schema = app.openapi()
(out / "openapi.json").write_text(json.dumps(schema, indent=2), encoding="utf-8")

summary = {
    "title": schema["info"]["title"],
    "version": schema["info"]["version"],
    "path_count": len(schema.get("paths", {})),
    "paths": sorted(schema.get("paths", {}).keys()),
    "tags": [tag["name"] for tag in schema.get("tags", [])],
    "docs": ["/docs", "/redoc", "/openapi.json"],
}
(out / "openapi_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
