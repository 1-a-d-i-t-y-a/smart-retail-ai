from pathlib import Path
import json, subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / 'artifacts' / 'final'
ART.mkdir(parents=True, exist_ok=True)

# Final regression suite
p = subprocess.run([sys.executable, '-m', 'pytest', '-q'], cwd=ROOT, text=True, capture_output=True)
pytest_output = (p.stdout + '\n' + p.stderr).strip()

# Load key evidence
with open(ROOT/'artifacts/evaluation/model_evaluation.json', encoding='utf-8') as f: ev = json.load(f)
with open(ROOT/'artifacts/end_to_end/end_to_end_evaluation.json', encoding='utf-8') as f: e2e = json.load(f)
with open(ROOT/'artifacts/deployment/deployment_verification.json', encoding='utf-8') as f: dep = json.load(f)
with open(ROOT/'artifacts/api/openapi_summary.json', encoding='utf-8') as f: api = json.load(f)

summary = {
  'project': 'AI-Powered Smart Retail & Customer Intelligence Platform',
  'status': 'final_evidence_package_complete',
  'reconstructed_project': True,
  'regression_suite': {'status': 'passed' if p.returncode == 0 else 'failed', 'pytest_output': pytest_output},
  'model_evaluation': {
    'product_controlled_cv_accuracy': ev['product']['cross_validation']['mean_accuracy'],
    'product_challenge_accuracy': ev['product']['challenge_holdout']['accuracy'],
    'sentiment_controlled_cv_accuracy': ev['sentiment']['cross_validation']['mean_accuracy'],
    'sentiment_challenge_accuracy': ev['sentiment']['challenge_holdout']['accuracy'],
    'face_controlled_accuracy': ev['face']['accuracy_at_0_52'],
    'face_note': ev['face']['note'],
  },
  'api': {'path_count': api['path_count'], 'paths': api['paths'], 'docs': api['docs']},
  'end_to_end': {'passed': e2e['passed'], 'total': e2e['total']},
  'deployment': dep,
  'evidence_directories': ['artifacts/product','artifacts/face','artifacts/sentiment','artifacts/chatbot','artifacts/integration','artifacts/testing','artifacts/evaluation','artifacts/api','artifacts/deployment','artifacts/end_to_end','artifacts/final'],
  'interpretation': 'All artifacts are reconstructed/re-implemented project evidence. Controlled perfect scores are not presented as evidence of real-world generalization. Docker runtime was not executed because the Docker CLI was unavailable in the execution environment.'
}
with open(ART/'final_evidence_summary.json','w',encoding='utf-8') as f:
    json.dump(summary,f,indent=2)

md = f'''# Part 2 — Step 6: Final Project Evidence Package

## Purpose

This directory consolidates report-ready evidence for the reconstructed AI/ML internship project.

## Final verification

- Automated regression suite: **{pytest_output.splitlines()[0] if pytest_output else 'see summary JSON'}**
- API documentation: **{api['path_count']} documented paths**
- End-to-end workflows: **{e2e['passed']}/{e2e['total']} passed**
- Deployment configuration: **validated**
- Docker runtime: **not executed because Docker CLI was unavailable**

## Model-evaluation interpretation

| Component | Controlled evaluation | Challenge evaluation |
|---|---:|---:|
| Product classification | {ev['product']['cross_validation']['mean_accuracy']*100:.1f}% CV accuracy | {ev['product']['challenge_holdout']['accuracy']*100:.1f}% |
| Sentiment analysis | {ev['sentiment']['cross_validation']['mean_accuracy']*100:.1f}% CV accuracy | {ev['sentiment']['challenge_holdout']['accuracy']*100:.1f}% |
| Face verification | {ev['face']['accuracy_at_0_52']*100:.1f}% controlled benchmark | Controlled perturbation benchmark only |

The challenge results are deliberately retained because they expose the difference between performance on controlled reconstructed data and harder, independently generated/hand-written evaluation samples.

## Evidence map

- Product: `artifacts/product/`
- Face: `artifacts/face/`
- Sentiment: `artifacts/sentiment/`
- Chatbot: `artifacts/chatbot/`
- Integration: `artifacts/integration/`
- Error handling: `artifacts/testing/`
- Model evaluation: `artifacts/evaluation/`
- API/OpenAPI: `artifacts/api/`
- Deployment: `artifacts/deployment/`
- End-to-end: `artifacts/end_to_end/`

## Reporting note

These artifacts are **reconstructed/re-implemented evidence** based on the project specification. They must not be described as original historical internship screenshots, logs, datasets, or telemetry unless independently supported by the user's original records.
'''
(ART/'FINAL_EVIDENCE.md').write_text(md, encoding='utf-8')

# Copy a concise status document at docs level
(ROOT/'docs'/'part2_step6.md').write_text(md, encoding='utf-8')

# Update README final status
readme = (ROOT/'README.md').read_text(encoding='utf-8')
append = f'''\n\n## Part 2 — Final Evidence Package\n\nFinal report-ready evidence is consolidated under `artifacts/final/` and mapped to each project stage. The complete regression suite currently reports **{pytest_output.splitlines()[0] if pytest_output else 'see test output'}**. End-to-end evaluation is **{e2e['passed']}/{e2e['total']} workflows passed**. Docker configuration is validated, but Docker runtime was not executed because the Docker CLI was unavailable in the execution environment. All evidence is explicitly treated as reconstructed/re-implemented project evidence.\n'''
if '## Part 2 — Final Evidence Package' not in readme:
    (ROOT/'README.md').write_text(readme + append, encoding='utf-8')

print('Final evidence package created.')
print(pytest_output)
