from __future__ import annotations
import json
from pathlib import Path
import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import ConfusionMatrixDisplay

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / 'artifacts' / 'sentiment'
ART.mkdir(parents=True, exist_ok=True)
model = joblib.load(ROOT / 'models' / 'sentiment_classifier.joblib')
metrics = json.loads((ART/'metrics.json').read_text())
classes = metrics['classes']
cm = np.array(metrics['confusion_matrix'])

# 1. Confusion matrix
fig, ax = plt.subplots(figsize=(7.2, 5.8))
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=classes)
disp.plot(ax=ax, cmap='Blues', values_format='d', colorbar=False)
ax.set_title('Retail Sentiment Analysis — Confusion Matrix')
fig.tight_layout()
fig.savefig(ART/'confusion_matrix.png', dpi=180, bbox_inches='tight')
plt.close(fig)

# 2. Classification report table
rows=[]
for c in classes:
    r=metrics['classification_report'][c]
    rows.append([c, r['precision'], r['recall'], r['f1-score'], int(r['support'])])
fig, ax = plt.subplots(figsize=(8.6, 3.8))
ax.axis('off')
table=ax.table(cellText=[[r[0], f'{r[1]:.2f}', f'{r[2]:.2f}', f'{r[3]:.2f}', r[4]] for r in rows],
               colLabels=['Class','Precision','Recall','F1-score','Support'], loc='center', cellLoc='center')
table.auto_set_font_size(False); table.set_fontsize(10); table.scale(1,1.55)
ax.set_title('Classification Report — Held-out Test Set', pad=18)
fig.tight_layout()
fig.savefig(ART/'classification_report.png', dpi=180, bbox_inches='tight')
plt.close(fig)

# 3. Inference examples
examples = [
    'The customer loved the premium quality and fast delivery.',
    'The package arrived on Tuesday and contains two products.',
    'The delivery was very late and the customer is unhappy.',
    'The product is available in black and has a one year warranty.',
    'The support team solved my issue quickly.'
]
preds=model.predict(examples)
probs=model.predict_proba(examples)
records=[]
for t,p,pr in zip(examples,preds,probs):
    records.append({'text':t,'predicted_sentiment':str(p),'confidence':float(pr.max())})
pd.DataFrame(records).to_csv(ART/'inference_examples.csv', index=False)

# 4. Combined evidence sheet
fig = plt.figure(figsize=(12, 8.5))
gs = fig.add_gridspec(2,2, height_ratios=[1,1.05])
ax1=fig.add_subplot(gs[0,0]); ax1.imshow(plt.imread(ART/'confusion_matrix.png')); ax1.axis('off')
ax2=fig.add_subplot(gs[0,1]); ax2.imshow(plt.imread(ART/'classification_report.png')); ax2.axis('off')
ax3=fig.add_subplot(gs[1,:]); ax3.axis('off')
text_lines=[
    'AI/ML Smart Retail — Sentiment Analysis Evidence',
    f'Model: TF-IDF (1–2 grams) + Logistic Regression',
    f'Train samples: {metrics["train_samples"]} | Test samples: {metrics["test_samples"]} | Accuracy: {metrics["accuracy"]:.2%}',
    '',
    'API endpoint: POST /analyze-sentiment',
    'Sample inference:'
]
for rec in records[:4]:
    text_lines.append(f'• {rec["predicted_sentiment"].upper()} ({rec["confidence"]:.2%}) — {rec["text"]}')
ax3.text(0.02,0.98,'\n'.join(text_lines),va='top',fontsize=11,wrap=True)
fig.suptitle('Reconstructed Project Evidence — Sentiment Analysis', fontsize=16, y=0.995)
fig.tight_layout(rect=[0,0,1,0.98])
fig.savefig(ART/'sentiment_analysis_evidence.png', dpi=170, bbox_inches='tight')
plt.close(fig)

# 5. Machine-readable evaluation summary
summary={
    'component':'sentiment_analysis',
    'method':'TF-IDF vectorization with 1-2 grams + Logistic Regression',
    'train_samples':metrics['train_samples'],
    'test_samples':metrics['test_samples'],
    'accuracy':metrics['accuracy'],
    'classes':classes,
    'api_endpoint':'POST /analyze-sentiment',
    'note':'These are reconstruction results on a controlled synthetic retail sentiment dataset; they are not original internship metrics.'
}
(ART/'evaluation_summary.json').write_text(json.dumps(summary, indent=2))
print('Generated sentiment evidence artifacts.')
