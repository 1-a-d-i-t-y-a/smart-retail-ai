from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient

from app.main import app
ART_DIR = ROOT / "artifacts" / "integration"
ART_DIR.mkdir(parents=True, exist_ok=True)


def run() -> dict:
    client = TestClient(app)
    before = client.get("/dashboard/stats").json()

    checks = []

    # 1. Gateway health
    r = client.get("/health")
    checks.append({"component": "health", "endpoint": "GET /health", "status_code": r.status_code,
                   "passed": r.status_code == 200 and r.json().get("status") == "healthy"})

    # 2. Product classification
    product = ROOT / "data" / "products" / "bottle" / "bottle_000.png"
    with product.open("rb") as f:
        r = client.post("/classify-product", files={"file": (product.name, f, "image/png")})
    body = r.json()
    checks.append({"component": "product classification", "endpoint": "POST /classify-product",
                   "status_code": r.status_code, "passed": r.status_code == 200 and "product" in body,
                   "response": body})

    # 3. Face recognition
    face = ROOT / "data" / "faces" / "person_01_reference.png"
    with face.open("rb") as f:
        r = client.post("/recognize-face", files={"file": (face.name, f, "image/png")})
    body = r.json()
    checks.append({"component": "face recognition", "endpoint": "POST /recognize-face",
                   "status_code": r.status_code, "passed": r.status_code == 200 and body.get("matched") is True,
                   "response": body})

    # 4. Sentiment analysis
    r = client.post("/analyze-sentiment", json={"text": "The delivery was very late and the customer is unhappy."})
    body = r.json()
    checks.append({"component": "sentiment analysis", "endpoint": "POST /analyze-sentiment",
                   "status_code": r.status_code, "passed": r.status_code == 200 and body.get("sentiment") in {"negative", "neutral", "positive"},
                   "response": body})

    # 5. Retail chatbot
    r = client.post("/chatbot", json={"message": "How do I request a return?"})
    body = r.json()
    checks.append({"component": "retail chatbot", "endpoint": "POST /chatbot",
                   "status_code": r.status_code, "passed": r.status_code == 200 and body.get("intent") == "returns",
                   "response": body})

    # 6. Dashboard aggregation
    after = client.get("/dashboard/stats").json()
    delta = {k: after[k] - before[k] for k in after}
    expected = {
        "total_requests": 4,
        "product_requests": 1,
        "face_requests": 1,
        "sentiment_requests": 1,
        "chatbot_requests": 1,
    }
    dashboard_passed = delta == expected
    checks.append({"component": "dashboard aggregation", "endpoint": "GET /dashboard/stats",
                   "status_code": 200, "passed": dashboard_passed,
                   "before": before, "after": after, "delta": delta, "expected_delta": expected})

    # Verify all documented gateway paths are present.
    paths = sorted(app.openapi()["paths"].keys())
    required_paths = [
        "/health", "/classify-product", "/recognize-face", "/analyze-sentiment",
        "/chatbot", "/dashboard/stats",
    ]
    openapi_passed = all(path in paths for path in required_paths)
    checks.append({"component": "OpenAPI gateway", "endpoint": "GET /openapi.json",
                   "status_code": 200, "passed": openapi_passed,
                   "required_paths": required_paths})

    passed = sum(bool(c["passed"]) for c in checks)
    summary = {
        "component": "FastAPI unified integration",
        "checks": checks,
        "passed": passed,
        "total": len(checks),
        "all_passed": passed == len(checks),
        "note": "Reconstruction smoke test executed against the local FastAPI gateway; results are not original historical internship telemetry.",
    }
    (ART_DIR / "integration_smoke.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    if not summary["all_passed"]:
        raise SystemExit(1)
    return summary


if __name__ == "__main__":
    run()
