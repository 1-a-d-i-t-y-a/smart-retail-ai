from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)
ROOT = Path(__file__).resolve().parents[1]


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "healthy"


def test_sentiment():
    r = client.post("/analyze-sentiment", json={"text": "The product quality is excellent and I am very happy."})
    assert r.status_code == 200
    assert r.json()["sentiment"] in {"positive", "negative", "neutral"}


def test_chatbot():
    r = client.post("/chatbot", json={"message": "How do I request a return?"})
    assert r.status_code == 200
    assert r.json()["intent"] == "returns"


def test_product():
    img = ROOT / "data" / "products" / "bottle" / "bottle_000.png"
    with img.open("rb") as f:
        r = client.post("/classify-product", files={"file": (img.name, f, "image/png")})
    assert r.status_code == 200
    assert "product" in r.json()


def test_face():
    img = ROOT / "data" / "faces" / "person_01_reference.png"
    with img.open("rb") as f:
        r = client.post("/recognize-face", files={"file": (img.name, f, "image/png")})
    assert r.status_code == 200
    assert r.json()["matched"] is True


def test_dashboard():
    r = client.get("/dashboard/stats")
    assert r.status_code == 200
    assert r.json()["total_requests"] >= 0
