from app.services.chatbot_service import classify_message, reply


def test_chatbot_intent_matrix():
    cases = {
        "Hello, can you help me?": "greeting",
        "Can you recommend headphones?": "products",
        "Where is my order?": "order_status",
        "How long will delivery take?": "shipping",
        "I want a refund": "returns",
        "What are the store hours?": "store_info",
        "Can I pay by UPI?": "payment",
        "I have a complaint": "support",
        "Tell me a random joke": "fallback",
    }
    for message, expected in cases.items():
        assert classify_message(message)["intent"] == expected


def test_chatbot_response_contract():
    result = reply("How do I return a product?")
    assert set(result) == {"intent", "response"}
    assert result["intent"] == "returns"
    assert result["response"]


def test_chatbot_is_case_insensitive():
    assert classify_message("TRACK MY ORDER PLEASE")["intent"] == "order_status"
