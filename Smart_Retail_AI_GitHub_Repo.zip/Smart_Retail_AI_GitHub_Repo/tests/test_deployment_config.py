from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCKERFILE = ROOT / "Dockerfile"
COMPOSE = ROOT / "docker-compose.yml"


def test_dockerfile_has_production_startup_and_healthcheck():
    text = DOCKERFILE.read_text()
    assert "python:3.11-slim" in text
    assert "pip install --no-cache-dir -r requirements.txt" in text
    assert 'EXPOSE 8000' in text
    assert 'uvicorn"' in text and 'app.main:app' in text
    assert 'HEALTHCHECK' in text and '/health/ready' in text


def test_compose_exposes_api_and_healthcheck():
    text = COMPOSE.read_text()
    assert '"8000:8000"' in text
    assert 'SMART_RETAIL_ENV: production' in text
    assert '/health/ready' in text
    assert 'start_period: 20s' in text


def test_required_deployment_files_exist():
    for path in [DOCKERFILE, COMPOSE, ROOT / ".env.example", ROOT / "requirements.txt"]:
        assert path.exists(), path


def test_all_python_files_compile():
    import py_compile
    for path in ROOT.rglob("*.py"):
        if ".pytest_cache" not in path.parts:
            py_compile.compile(str(path), doraise=True)
