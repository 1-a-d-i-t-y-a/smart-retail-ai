import json
from pathlib import Path

def test_end_to_end_evaluation_passed():
    p=Path('artifacts/end_to_end/end_to_end_evaluation.json')
    data=json.loads(p.read_text())
    assert data['all_passed'] is True
    assert data['passed']==data['total']==5
