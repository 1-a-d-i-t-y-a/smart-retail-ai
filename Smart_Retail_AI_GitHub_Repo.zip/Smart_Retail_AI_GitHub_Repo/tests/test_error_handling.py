from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)
ROOT = Path(__file__).resolve().parents[1]


def test_product_rejects_non_image_upload():
    response = client.post(
        "/classify-product",
        files={"file": ("notes.txt", b"not an image", "text/plain")},
    )
    assert response.status_code == 400
    assert "image" in response.json()["detail"].lower()


def test_product_rejects_malformed_image():
    response = client.post(
        "/classify-product",
        files={"file": ("broken.png", b"this is not a real png", "image/png")},
    )
    assert response.status_code == 400
    assert "decode" in response.json()["detail"].lower()


def test_face_rejects_empty_upload():
    response = client.post(
        "/recognize-face",
        files={"file": ("empty.png", b"", "image/png")},
    )
    assert response.status_code == 400
    assert "empty" in response.json()["detail"].lower()


def test_face_handles_image_without_face():
    image = ROOT / "data" / "faces" / "negative_astronaut.png"
    response = client.post(
        "/recognize-face",
        files={"file": (image.name, image.read_bytes(), "image/png")},
    )
    assert response.status_code == 200
    assert response.json()["matched"] is False


def test_sentiment_rejects_blank_text():
    response = client.post("/analyze-sentiment", json={"text": "   "})
    assert response.status_code == 422


def test_sentiment_rejects_missing_text():
    response = client.post("/analyze-sentiment", json={})
    assert response.status_code == 422


def test_chatbot_rejects_blank_message():
    response = client.post("/chatbot", json={"message": "   "})
    assert response.status_code == 422


def test_chatbot_rejects_overlong_message():
    response = client.post("/chatbot", json={"message": "x" * 2001})
    assert response.status_code == 422


def test_product_rejects_oversized_image_payload():
    response = client.post(
        "/classify-product",
        files={"file": ("large.png", b"0" * (5 * 1024 * 1024 + 1), "image/png")},
    )
    assert response.status_code == 400
    assert "5 mb" in response.json()["detail"].lower()


def test_product_accepts_valid_image():
    image = ROOT / "data" / "products" / "bottle" / "bottle_000.png"
    response = client.post(
        "/classify-product",
        files={"file": (image.name, image.read_bytes(), "image/png")},
    )
    assert response.status_code == 200
    assert response.json()["product"].lower() in {"bottle", "mug", "headphones", "shoe"}
