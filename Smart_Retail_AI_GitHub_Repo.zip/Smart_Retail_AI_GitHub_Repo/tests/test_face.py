from pathlib import Path

from app.services.face_service import build_face_db, recognize_face

ROOT = Path(__file__).resolve().parents[1]
FACE_DIR = ROOT / "data" / "faces"


def test_face_reference_matches(tmp_path):
    build_face_db(FACE_DIR / "person_01_reference.png", threshold=0.52)
    result = recognize_face((FACE_DIR / "person_01_reference.png").read_bytes())
    assert result["matched"] is True
    assert result["person"] == "person_01"


def test_face_positive_query_matches():
    result = recognize_face((FACE_DIR / "person_01_query.png").read_bytes())
    assert result["matched"] is True
    assert result["person"] == "person_01"


def test_face_negative_does_not_match():
    result = recognize_face((FACE_DIR / "negative_astronaut.png").read_bytes())
    assert result["matched"] is False
    assert result["person"] is None
