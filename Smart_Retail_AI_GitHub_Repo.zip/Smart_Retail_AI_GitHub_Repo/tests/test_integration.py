from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)
ROOT = Path(__file__).resolve().parents[1]


def test_unified_gateway_paths():
    paths = app.openapi()["paths"]
    for path in [
        "/health",
        "/classify-product",
        "/recognize-face",
        "/analyze-sentiment",
        "/chatbot",
        "/dashboard/stats",
    ]:
        assert path in paths


def test_unified_ai_workflow():
    product = ROOT / "data" / "products" / "bottle" / "bottle_000.png"
    with product.open("rb") as f:
        product_response = client.post("/classify-product", files={"file": (product.name, f, "image/png")})
    assert product_response.status_code == 200

    face = ROOT / "data" / "faces" / "person_01_reference.png"
    with face.open("rb") as f:
        face_response = client.post("/recognize-face", files={"file": (face.name, f, "image/png")})
    assert face_response.status_code == 200
    assert face_response.json()["matched"] is True

    sentiment_response = client.post(
        "/analyze-sentiment",
        json={"text": "The delivery was very late and the customer is unhappy."},
    )
    assert sentiment_response.status_code == 200
    assert sentiment_response.json()["sentiment"] in {"negative", "neutral", "positive"}

    chatbot_response = client.post("/chatbot", json={"message": "How do I request a return?"})
    assert chatbot_response.status_code == 200
    assert chatbot_response.json()["intent"] == "returns"
