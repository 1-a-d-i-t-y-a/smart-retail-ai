import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EVAL = ROOT / "artifacts" / "evaluation" / "model_evaluation.json"


def load_eval():
    assert EVAL.exists(), "Deep evaluation artifact is missing"
    return json.loads(EVAL.read_text(encoding="utf-8"))


def test_product_cross_validation_is_recorded():
    data = load_eval()["product"]["cross_validation"]
    assert data["folds"] == 5
    assert len(data["scores"]) == 5
    assert 0.0 <= data["mean_accuracy"] <= 1.0


def test_sentiment_cross_validation_is_recorded():
    data = load_eval()["sentiment"]["cross_validation"]
    assert data["folds"] == 5
    assert len(data["scores"]) == 5
    assert 0.0 <= data["mean_accuracy"] <= 1.0


def test_face_controlled_evaluation_is_recorded():
    data = load_eval()["face"]
    assert data["cases"] == len(data["results"])
    assert data["correct"] <= data["cases"]
    assert 0.0 <= data["accuracy_at_0_52"] <= 1.0
    assert data["roc_auc"] is not None
    assert len(data["threshold_sweep"]) > 0


def test_challenge_holdouts_are_reported_separately():
    import json
    from pathlib import Path

    data = json.loads((Path("artifacts/evaluation/model_evaluation.json")).read_text())
    assert data["product"]["challenge_holdout"]["samples"] == 120
    assert data["sentiment"]["challenge_holdout"]["samples"] == 18
    assert data["product"]["challenge_holdout"]["accuracy"] < 1.0
    assert data["sentiment"]["challenge_holdout"]["accuracy"] < 1.0
