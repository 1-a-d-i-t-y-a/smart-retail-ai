from app.main import app


def test_openapi_contains_required_paths():
    schema = app.openapi()
    expected = {
        "/health",
        "/health/ready",
        "/classify-product",
        "/recognize-face",
        "/analyze-sentiment",
        "/chatbot",
        "/dashboard/stats",
    }
    assert expected.issubset(schema["paths"])


def test_openapi_has_documentation_metadata():
    schema = app.openapi()
    assert schema["info"]["title"]
    assert schema["info"]["version"]
    assert schema["tags"]
