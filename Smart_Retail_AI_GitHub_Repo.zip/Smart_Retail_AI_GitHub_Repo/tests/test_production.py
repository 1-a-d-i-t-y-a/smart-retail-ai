from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_readiness_reports_required_artifacts():
    response = client.get('/health/ready')
    assert response.status_code == 200
    body = response.json()
    assert body['status'] == 'ready'
    assert all(body['checks'].values())


def test_request_id_is_returned_and_propagated():
    response = client.get('/health', headers={'X-Request-ID': 'part2-test-001'})
    assert response.status_code == 200
    assert response.headers['X-Request-ID'] == 'part2-test-001'


def test_security_headers_are_present():
    response = client.get('/health')
    assert response.headers['X-Content-Type-Options'] == 'nosniff'
    assert response.headers['X-Frame-Options'] == 'DENY'
    assert response.headers['Referrer-Policy'] == 'no-referrer'


def test_openapi_exposes_system_readiness_route():
    response = client.get('/openapi.json')
    assert response.status_code == 200
    paths = response.json()['paths']
    assert '/health/ready' in paths
